import React from "react";
import styles from "../assets/styles/Banner.module.scss";

const Banner = () => {
  return <div className={styles.banner}></div>;
};

export default Banner;
